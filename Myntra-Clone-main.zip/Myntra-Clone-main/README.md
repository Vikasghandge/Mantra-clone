<img width="960" alt="Home" src="https://user-images.githubusercontent.com/96285027/235316694-52148226-09f7-494f-9012-6dec10d2980c.png">
<img width="960" alt="House-living" src="https://user-images.githubusercontent.com/96285027/235316695-d4fbbb63-c890-427c-b133-645f85ef4774.png">
<img width="960" alt="Login" src="https://user-images.githubusercontent.com/96285027/235316699-840e1497-3283-4cbd-8d74-0b3f4776b384.png">
<img width="960" alt="Body" src="https://user-images.githubusercontent.com/96285027/235316690-ddaf3784-2032-4664-99be-4f14d7290dd9.png">
<img width="960" alt="Kids" src="https://user-images.githubusercontent.com/96285027/235316697-ab638fc2-2350-4f41-92d5-8d391d8ce7fc.png">
<img width="960" alt="men" src="https://user-images.githubusercontent.com/96285027/235316701-86bc22bb-00ee-4b52-b0a8-5f8236b687a3.png">
<img width="960" alt="Women" src="https://user-images.githubusercontent.com/96285027/235316702-5fb0b3c4-b4bd-4f31-a904-ec39f51ffbff.png">
<img width="960" alt="Footer" src="https://user-images.githubusercontent.com/96285027/235316693-470db710-4d14-4724-9af1-7879c2c46a2a.png">
